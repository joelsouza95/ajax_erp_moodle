import '../styles/main.scss'

console.log(':)')
